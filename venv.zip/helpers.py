from openai import OpenAI
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Access the OpenAI API key
openai_api_key = os.getenv("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")

import instructor

# Initialize OpenAI client
open_ai_client = OpenAI(
    api_key=openai_api_key,
)

instructor.patch(open_ai_client)

def structured_generator(openai_model, prompt, custom_model):
    result = open_ai_client.chat.completions.create(
        model=openai_model,
        response_model=custom_model,
        messages=[{"role": "user", "content": f"{prompt}, output must be in json"}]
    )
    return result

import openai
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Access the OpenAI API key from the environment variable
openai_api_key = os.getenv("OPENAI_API_KEY")

# Check if the API key is loaded correctly
if not openai_api_key:
    raise ValueError("API key is missing. Please set it in the .env file.")

# Set the OpenAI API key for the client
openai.api_key = openai_api_key

import instructor

# Patch instructor with OpenAI client
instructor.patch(openai)

def structured_generator(openai_model, prompt, custom_model):
    result = openai.ChatCompletion.create(
        model=openai_model,
        messages=[{"role": "user", "content": f"{prompt}, output must be in json"}]
    )
    return result
